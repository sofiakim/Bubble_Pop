import java.awt.Color;
import hsa.Console;

/** The "Temp" class.
  * A brief description of this class
  * @author your name
  * @version date
 */
public class Temp
{
    public static void main (String[] args)
    {
	Console c = new Console ("Temp");
    } // main method


    /** This section of code makes a stone crack and causes it to turn into a bubble
      * @param lastRow the row of the last popped bubble
      * @param lastCol the column of the last popped bubble
      * @param board the board of the game
      */
    public void crackedBubble (int lastRow, int lastCol)
    {
	int randomGenerator = Math.random () * 7 + 1;
	// Checks for stones around the popped bubble and turns them into cracked stones
	if (board [lastRow] [lastCol + 1] == STONE)
	{
	    board [lastRow] [lastCol + 1] = CRACKED;
	    repaint ();
	}
	if (board [lastRow] [lastCol - 1] == STONE)
	{
	    board [lastRow] [lastCol - 1] = CRACKED;
	    repaint ();
	}
	if (board [lastRow + 1] [lastCol] == STONE)
	{
	    board [lastRow + 1] [lastCol] = CRACKED;
	    repaint ();
	}
	if (board [lastRow - 1] [lastCol] == STONE)
	{
	    board [lastRow - 1] [lastCol] = CRACKED;
	    repaint ();
	}

	// Checks for a cracked stone to the right the popped bubble and turns them into a numbered bubble
	if (board [lastRow] [lastCol + 1] == CRACKED)
	{
	    int number = randomGenerator;
	    board [lastRow] [lastCol + 1] = pieces [number];
	    repaint ();
	}
	if (board [lastRow] [lastCol - 1] == CRACKED)
	{
	    int number = randomGenerator;
	    board [lastRow] [lastCol + 1] = pieces [number];
	    repaint ();
	}
	if (board [lastRow + 1] [lastCol] == CRACKED)
	{
	    int number = randomGenerator;
	    board [lastRow] [lastCol + 1] = pieces [number];
	    repaint ();
	}
	if (board [lastRow - 1] [lastCol] == CRACKED)
	{
	    int number = randomGenerator;
	    board [lastRow] [lastCol + 1] = pieces [number];
	    repaint ();
	}
    }


    /** Checks for a game over
      * @return whether the game is over or not
      */
    private boolean checkForGameOver ()
    {
	return gameOver;
    }


    /** Increases the level
      */
    private void levelUp ()
    {
	if (levelBubbles == 0)
	{
	    for (int col = 0 ; col < 7 ; col++)
		board [7] [col] = STONE;
	    level++;
	    levelBubbles = 30 - level;
	}
	else
	    levelBubbles--;
    }


    /** Makes a move on the board (if possible)
      * @param colToMove the selected column to move in
      */
    private void makeMove (int colToMove)
    {
	// Checks for a game over
	checkForGameOver ();

	// Tells the player to start a new game once he or she reaches game over
	if (gameOver)
	{
	    JOptionPane.showMessageDialog (this,
		    "Please Select Game...New to start a new game",
		    "Game Over", JOptionPane.WARNING_MESSAGE);
	    return;
	}
	else  // Create a new piece (bubble or stone) to be dropped
	{
	    // Finds the row to drop the piece
	    int row = findRow (colToMove);
	    if (row <= 0)
	    {
		JOptionPane.showMessageDialog (this,
			"Please Select another Column",
			"Column is Full", JOptionPane.WARNING_MESSAGE);
		return;
	    }

	    int newPiece = pieces [(int) (Math.random () * 8 + 1)];

	    // Shows the piece dropping
	    if (ANIMATION_ON)
		animatePiece (newPiece, colToMove, row);
	    levelUp ();
	}
	
	// Start piece in centre
	currentColumn = NO_OF_COLUMNS / 2 + 1;
	repaint ();
    }
} // Temp class


